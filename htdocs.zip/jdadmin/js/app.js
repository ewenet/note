// Utils
var U = {
	_url: "be.php",
	_href : new Lee.Href(),
	_table : new Lee.Table(),
	_status : new Lee.Status(),
	_form : new Lee.Form(),
	_upload : new Lee.Upload(),
	_require : function(opt) {
		$.ajax({
			url: '/jdadmin/tpl/'+opt.path+'.html',
			type: 'GET',
			fail: function(response){
				opt.failFn && opt.failFn(response);
			},
			success: function(response){
				opt.successFn && opt.successFn(response);
			},
			complete: function(response){
				opt.completeFn && opt.completeFn(response);
			}
		});
	},
	getPath : function() {
		return U._href.getSPAHash('m').split('.')[0] + '/' + U._href.getSPAHash('m').split('.')[1];
	},
	load_and_show : function() {
		U._require({
			path: U.getPath(),
			successFn: function(response){
				$('#jda_main').empty().append(response);
			},
			completeFn: function() {
			}
		});
	},
	_trigger : function() {
		// $(window).on('popstate.trigger', function(){
		// 	$(window).trigger('hashchange.trigger');
		// });
		$(window).on('hashchange.trigger', U.load_and_show());
		// $(window).on('load.trigger', U.load_and_show());
	},
	chanageMenuStatus : function(status){
		var menu_parents = $('.level_1 > span'),
			menu_children = $('.level_2'),
			child = $('[data-parent="'+status.pmenu+'"]');
		menu_children.hide();
		menu_parents.removeClass('active');
		menu_children.find('span').removeClass('active');
		child && child.show();
		$('[data-me="'+status.pmenu+'"]').addClass('active');
		$('[data-me="'+status.cmenu+'"]').addClass('active');
	},
	render : function(form, opt) {
		var el;
		for(k in opt) {
			if( el = form.find('[data-id="'+k+'"]').eq(0) ) {
				el.val(opt[k]);
			}
		}
	}
};

(function() {
	this.run = function(){
		var spa_hash = U._href.getAllSPAHash();
		var m = spa_hash.m;
		var pmenu, cmenu, firstLoad;
		if(!m) {
			U._href.setSPAHash({'m': 'index.index'});
			m = 'index.index';
			pmenu = 'index';
			cmenu = null;
		} else {
			pmenu = m.split('.')[0];
			cmenu = m.split('.')[1];
		}
		U._status.set({
			'pmenu': pmenu,
			'cmenu': cmenu,
			'scripts': [],
			'showsidebar': true
		});
		U.chanageMenuStatus(U._status.map);
		this.events();
		U._trigger();
	};
	this.events = function(){
		var menu_parents = $('.level_1 > span');
		var menu_children = $('.level_2');
		var menu_children_span = menu_children.find('li span');
		var sidebar_toggle_btn = $('#sidebar_toggle_btn');

		// 一级菜单点击展开二级菜单并默认点击第一项
		menu_parents.on('click.struc', function(){
			var tis = $(this);
			var me = tis.data('me');
			var child = $('[data-parent="'+me+'"]');
			isActive = tis.hasClass('active');
			menu_children.hide();
			menu_parents.removeClass('active');
			child && child.show() && child.find('li span').eq(0).click();
			tis.addClass('active');
		});
		// 一级菜单点击触发功能
		menu_parents.on('click.func', function(){
			var tis = $(this);
			var js = tis.data('js');
			console.log(undefined != js);
			(undefined != js) && U._href.setSPAHash({'m': js});
			U._status.set({
				'pmenu': tis.data('me')
			});
			(undefined != js) && U.load_and_show();
			U.chanageMenuStatus(U._status.map);
		});
		// 二级菜单点击激活状态
		menu_children_span.on('click.struc', function(){
			var tis = $(this);
			tis.addClass('active');
		});
		// 二级菜单点击触发功能
		menu_children_span.on('click.func', function(){
			var tis = $(this);
			var js = tis.data('js');
			U._href.setSPAHash({'m': js});
			U._status.set({
				'cmenu': tis.data('me')
			});
			U.load_and_show();
			U.chanageMenuStatus(U._status.map);
		});
		// 收起/展开侧边栏
		sidebar_toggle_btn.on('click.toggle_sidebar', function() {
			var isShow = U._status.map.showsidebar;
			var className = isShow ? 'hide_sidebar' : '';
			var text = isShow ? '展开' : '收起';
			U._status.set({
				showsidebar: !isShow
			});
			$(this).text(text);
			$('body').removeClass('hide_sidebar');
			$('body').addClass(className);
		});
		$(window).on('hashchange', function(){
			var spa_hash = U._href.getAllSPAHash();
			var m = spa_hash.m;
			if(undefined == m) { return;}
			U._status.set({
				'm': m,
				'pmenu': m.split('.')[0],
				'cmenu': m.split('.')[1]
			});
			// console.log(window.location.href);
			// history.pushState({hash: window.location.hash}, null, window.location.href);
			U.chanageMenuStatus(U._status.map);
		});
		// $(window).on('popstate', function(){
		// 	console.log(history.state);
		// 	$(window).trigger('hashchange');
		// });
	};
	this.run();
}());
