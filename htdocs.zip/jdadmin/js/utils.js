var Lee = {};

/**
 * =====================================================================
 * HREF
 * =====================================================================
 */

Lee.Href = new Function();
// 获取某个参数
Lee.Href.prototype.getParam = function(name) {
	var reg = new RegExp('(^|&)'+name+'=([^&]*)(&|$)', 'i');
	var r = window.location.search.substr(1).match(reg);
	if(r!=null) {
		return unescape(r[2]);
	}
	return null;
}

// 获取所有参数
Lee.Href.prototype.getAllParams = function() {
	if(window.location.search.length == 0) {	return {};}
	var ps = window.location.search.substr(1).split('&');
	var res = {}, k, v;
	for(var i=0; i<ps.length; i++) {
		k = ps[i].split('=')[0];
		v = ps[i].split('=')[1];
		if(k!='' && v!=undefined) {
			res[k] = v;
		};
	}
	return res;
}

// 设置参数{key:value}
Lee.Href.prototype.setParam = function(opt) {
	var obj = this.getAllParams();
	for(var op in opt) {
		obj[op] = opt[op];
	}
	return window.location.search = this.toString(obj);
}

// 判断某个参数是否已经设置
Lee.Href.prototype.isSet = function(name) {
	var name = name + "=";
	return window.location.search.substr(1).indexOf(name)>-1;
}

// 将参数对象解析成字符串
Lee.Href.prototype.toString = function(obj) {
	var res = [];
	for(var ob in obj) {
		// console.log(ob);
		res.push(ob+'='+obj[ob]);
	}
	return res.join('&');
}

// 获取hash值
Lee.Href.prototype.getHash = function() {
	return window.location.hash.substr(1);
}

// 设置hash值
Lee.Href.prototype.setHash = function(value) {
	return window.location.hash = '#' + value;
}

// 获取所有SPA hash值
Lee.Href.prototype.getAllSPAHash = function(){
	if(window.location.hash.length == 0) {	return {};}
	var ps = window.location.hash.substr(1).split('&');
	var res = {}, k, v;
	for(var i=0; i<ps.length; i++) {
		k = ps[i].split('=')[0];
		v = ps[i].split('=')[1];
		if(k!='' && v!=undefined) {
			res[k] = v;
		};
	}
	return res;
}

// 重置SPA hash值
Lee.Href.prototype.setSPAHash = function(opt) {
	var obj = {};
	window.location.hash = '';
	for(var op in opt) {
		obj[op] = opt[op];
	}
	return window.location.hash = this.toString(obj);
}

// 替换SPA hash值
Lee.Href.prototype.changeSPAHash = function(opt) {
	var obj = this.getAllSPAHash();
	for(var op in opt) {
		obj[op] = opt[op];
	}
	return window.location.hash = this.toString(obj);
}

// 获取某一SPA hash值
Lee.Href.prototype.getSPAHash = function(key) {
	return this.getAllSPAHash()[key];
}



/**
 * =====================================================================
 * STATUS
 * =====================================================================
 */
Lee.Status = new Function();

Lee.Status.prototype.map = {};

Lee.Status.prototype.get = function(name) {
	return this.map[name];
};

Lee.Status.prototype.set = function(opt) {
	for(var key in opt) {
		this.map[key] = opt[key];
	}
	// return true;
};

Lee.Status.prototype.has = function(key) {
	return this.map.hasOwnProperty(key);
};

Lee.Status.prototype.length = function() {
	return this.map.length;
};


/**
 * =====================================================================
 * FORM
 * =====================================================================
 */

Lee.Form = new Function();

Lee.Form.prototype.create = function(opt) {
	var form = document.createElement('form');
	opt.id && form.setAttribute('id', opt.id);
	opt.class && form.setAttribute('class', opt.class);
	opt.parent && opt.parent.appendChild(form);
	if(opt.children) {
		for(var i=0; i<opt.children.length; i++) {
			var tis = opt.children[i];
			if(!tis.tag) { continue;}
			if('editor' == tis.tag) {
				var temp = document.createElement('textarea');
				form.appendChild(temp);
				$(temp).xheditor({
					'width': opt.width || '100%',
					'height': opt.height || '400px'
				});
			} else {
				var temp = document.createElement(tis.tag);
				if(['input'].indexOf(tis.tag) > -1) {
					tis.type && temp.setAttribute('type', tis.type);
					tis.placeholder && temp.setAttribute('placeholder', tis.placeholder);
				}
				tis.value && temp.setAttribute('value', tis.value);
				tis.data_id && (temp.dataset.id = tis.data_id);
				tis.src && temp.setAttribute('src', tis.src);
				tis.id && temp.setAttribute('id', tis.id);
				tis.class && temp.setAttribute('class', tis.class);
				tis.onclick && (temp.addEventListener('click', tis.onclick));
				if(tis.label) {
					var label = document.createElement('label');
					label.innerHTML = tis.label;
					label.setAttribute('class', 'label');
					form.appendChild(label);
				}
				form.appendChild(temp);
			}
		}
	}
};


/**
 * =====================================================================
 * TABLE
 * =====================================================================
 */
Lee.Table = new Function();

// Lee.Table.prototype.init = function(opt) {
// 	var table = document.createElement('table');
// 	var thead = document.createElement('thead');
// 	var tbody = document.createElement('tbody');
// 	var tfoot = document.createElement('tfoot');
// 	table.appendChild(thead);
// 	table.appendChild(tbody);
// 	table.appendChild(tfoot);

// 	if(opt.id) {
// 		table.setAttribute('id', opt.id);
// 	}

// 	if(opt.chk) {
// 		var th = document.createElement('th');
// 		th.innerHTML = '<input type="checkbox">';
// 		th.dataset.type = 'chk';
// 		thead.appendChild(th);
// 	}

// 	for(var i=0; i< opt['ths'].length; i++) {
// 		var _head = document.createElement('th');
// 		var colData = opt['ths'][i];
// 		console.log(colData);
// 		if(colData.type == 'text') {
// 			_head.innerHTML = colData.text;
// 		}
// 		thead.appendChild(_head);
// 	}

// 	opt.pagination && this.initPagi();

// 	document.getElementById('jda_main').appendChild(table);
	
// 	opt.pagination && this.initPagi();

// 	this.insertRow($('#postListTable'), [
// 		{'title': 'Hello World!', 'link': '#'},
// 		{'title': 'Lee'},
// 		{'title': 'Code'},
// 		{'title': 'PHP,TP5'},
// 		{'title': '2018-04-01 12:00:02'},
// 	]);
// 	this.insertRow($('#postListTable'), [
// 		{'title': 'Hello World!', 'link': '#'},
// 		{'title': 'Lee'},
// 		{'title': 'Code'},
// 		{'title': 'PHP,TP5'},
// 		{'title': '2018-04-01 12:00:02'},
// 	]);
// };

// Lee.Table.prototype.insertRow = function(table, rowData, pos) {
// 	var tbody = table.find('tbody');
// 	var thead = table.find('thead th');
// 	var tr = document.createElement('tr');
// 	for(var i = 0; i < rowData.length; i++) {
// 		if(thead[i].dataset.type == 'chk') {
// 			tr.innerHTML += '<td><input type="checkbox"></td>';
// 			rowData.unshift('chk');
// 		} else {
// 			if(!rowData[i]['link']) {
// 				tr.innerHTML += '<td>'+rowData[i]['title']+'</td>';
// 			} else {
// 				tr.innerHTML += '<td><a href="'+rowData[i]['link']+'">'+rowData[i]['title']+'</a></td>';
// 			}
// 		}
// 	}
// 	tbody.append(tr);
// }

// Lee.Table.prototype.initPagi = function() {
// 	var pagi_div = document.createElement('div');
// 	pagi_div.setAttribute('class', 'pagi_div');
// 	var btn_index = this.createElement({
// 		'tagName': 'button',
// 		'text': '|<',
// 		'class': 'pagi_btn',
// 	});
// 	pagi_div.appendChild(btn_index);
// 	var btn_prev = this.createElement({
// 		'tagName': 'button',
// 		'text': '<',
// 		'class': 'pagi_btn'
// 	});
// 	pagi_div.appendChild(btn_prev);
// 	var pagi_inp = this.createElement({
// 		'tagName': 'input',
// 		'class': 'pagi_inp',
// 		'default': 1
// 	});
// 	pagi_div.appendChild(pagi_inp);
// 	var btn_next = this.createElement({
// 		'tagName': 'button',
// 		'text': '>',
// 		'class': 'pagi_btn'
// 	});
// 	pagi_div.appendChild(btn_next);
// 	var btn_last = this.createElement({
// 		'tagName': 'button',
// 		'text': '>|',
// 		'class': 'pagi_btn',
// 	});
// 	pagi_div.appendChild(btn_last);
// 	document.getElementById('jda_main').appendChild(pagi_div);
// }

// Lee.Table.prototype.createElement = function(opt) {
// 	var temp = document.createElement(opt.tagName);
// 	opt.text && (temp.innerHTML = opt.text);
// 	opt.class && temp.setAttribute('class', opt.class);
// 	opt.id && temp.setAttribute('id', opt.id);
// 	if(opt.tagName == 'input' && opt.default) {
// 		temp.setAttribute('placeholder', opt.default);
// 		temp.setAttribute('value', opt.default);
// 	}
// 	return temp;
// }
Lee.Table.prototype.init = function(opt){
	var defaults = {
		el: $('[data-component="table"]')
	};
	opt = $.extend({}, defaults, opt);
	var table = $('<table><thead></thead><tbody></tbody><tfoot></tfoot></table>');
	var thead = table.find('thead');
	for(var i=0; i<opt.ths.length; i++) {
		var tis = opt.ths[i];
		var inner_html = tis.type=='chk' ? '<input type="checkbox">' : tis.text;
		var type = tis.type=='chk' ? ' data-type="chk"': '';
		var sort = tis.sortable ? ' data-sort="1"' : '';
		var width = tis.width ? ' width="'+tis.width+'"' : '';
		var slug = tis.slug ? ' data-slug="'+tis.slug+'"' : '';
		inner_html = (tis.sortable && tis.slug) ? inner_html+'<i class="table-sort-icon" data-sortcol="'+tis.slug+'">↕</i>' : inner_html;
		thead.append('<th'+type+sort+width+slug+'>'+inner_html+'</th>');
	}
	opt.el.append(table);
};
Lee.Table.prototype.insertRows = function(opt) {
	var defaults = {
		el: $('[data-component="table"]')
	};
	var opt = $.extend({}, defaults, opt);
	var ths = opt.el.find('thead th');
	var tbody = opt.el.find('tbody');
	for(var i=0; i<opt.rowData.length; i++) {
		var tis = opt.rowData[i];
		var inner_html = '';
		var tr = $('<tr></tr>');
		for(var j=0; j<tis.length; j++) {
			if($(ths[j]).data('type')=='chk') {
				inner_html = '<input type="checkbox">';
				tis.unshift('');
			} else {
				var id = tis[j].link ? ' data-id="'+tis[j].link+'" data-fn="link"' : '';
				var m = tis[j].m ? ' data-m="'+tis[j].m+'"' : '';
				inner_html = '<span '+id+m+'>' + tis[j].text + '</span>';
			}
			tr.append('<td>'+inner_html+'</td>');
		}
		tbody.append(tr);
	}
};





/**
 * =====================================================================
 * FORM
 * =====================================================================
 */

Lee.Form = new Function();

Lee.Form.prototype.create = function(opt) {
	var form = document.createElement('form');
	opt.id && form.setAttribute('id', opt.id);
	opt.class && form.setAttribute('class', opt.class);
	opt.parent && opt.parent.appendChild(form);
	if(opt.children) {
		for(var i=0; i<opt.children.length; i++) {
			var tis = opt.children[i];
			if(!tis.tag) { continue;}
			if('editor' == tis.tag) {
				var temp = document.createElement('textarea');
				form.appendChild(temp);
				$(temp).xheditor({
					'width': opt.width || '100%',
					'height': opt.height || '400px'
				});
			} else {
				var temp = document.createElement(tis.tag);
				if(['input'].indexOf(tis.tag) > -1) {
					tis.type && temp.setAttribute('type', tis.type);
					tis.placeholder && temp.setAttribute('placeholder', tis.placeholder);
				}
				tis.value && temp.setAttribute('value', tis.value);
				tis.data_id && (temp.dataset.id = tis.data_id);
				tis.src && temp.setAttribute('src', tis.src);
				tis.id && temp.setAttribute('id', tis.id);
				tis.class && temp.setAttribute('class', tis.class);
				tis.onclick && (temp.addEventListener('click', tis.onclick));
				if(tis.label) {
					var label = document.createElement('label');
					label.innerHTML = tis.label;
					label.setAttribute('class', 'label');
					form.appendChild(label);
				}
				form.appendChild(temp);
			}
		}
	}
};


/**
 * =====================================================================
 * Upload
 * =====================================================================
 */

Lee.Upload = new Function();

Lee.Upload.prototype.list = [];

Lee.Upload.prototype.init = function(id) {
	var tis = this,
		el = document.getElementById(id);
	if(!el) { return;}
	el.ondragover = function(e){
		e.preventDefault();
		$(el).addClass('dragover');
	};
	el.ondragleave = function(e) {
		e.preventDefault();
		$(el).removeClass('dragover');
	}
	el.ondrop = function(e){
		e.preventDefault();
		var files = e.dataTransfer.files;
		function readShowSave(file) {
			// Make sure `file.name` matches our extensions criteria
		    if ( /\.(jpe?g|png|gif)$/i.test(file.name) ) {
				var reader = new FileReader();
				reader.addEventListener("load", function () {
					var imageDiv = document.createElement('div');
					imageDiv.className = 'media-show-img-div';
					var image = new Image();
					image.className = 'media-show-img';
					image.height = 100;
					image.title = file.name;
					image.src = this.result;
					imageDiv.appendChild( image );
					document.querySelector('#media-show-box').appendChild( imageDiv );
					// 传给后台
				}, false);
				reader.readAsDataURL(file);
		    }
		}
		if(files) {
			[].forEach.call(files, readShowSave);
		}
		$(el).removeClass('dragover');
	};
};

Lee.Upload.prototype.show = function(id, data) {
	var el = document.getElementById(id);
	console.log(data);
	var img = $('<img src="'+data.url+'" class="media-show-img" width="150"/>');
	$(el).append(img);
};

Lee.Upload.prototype.save = function(data) {
	//传给后台
}