$.ajax({
	url: '/jdadmin/components/test/index.html',
	type: 'GET',
	dataType: 'html',
	success: function(response) {
		console.log(response);
	},
	complete: function(){
		console.log('complete');
	}
});