U._trigger('postcate', 'post_cate');

M['post_cate'] = function(){
	(U._href.getSPAHash('m') == 'post.cate') && (TPL = function(){
		this.run = function() {
			var main = $('#jda_main');
			main.empty();
			main.html('<h1 class="jda_page_title">分类目录</h1>');
		};
	}, (new TPL()).run());
}
