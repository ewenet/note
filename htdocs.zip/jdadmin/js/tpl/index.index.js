U._trigger('indexindex', 'index_index');

M['index_index'] = function(){
	(U._href.getSPAHash('m') == 'index.index') && (TPL = function(){
		this.run = function() {
			var main = $('#jda_main');
			main.empty();
			main.html('<h1 class="jda_page_title">仪表盘</h1>');
		};
	}, (new TPL()).run());
}
