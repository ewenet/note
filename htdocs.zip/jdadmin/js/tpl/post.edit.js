U._trigger('postedit', 'post_edit');

M['post_edit'] = function() {
	(U._href.getSPAHash('m') == 'post.edit') && (TPL = function(){
		this.run = function() {
			var main = $('#jda_main');
			main.empty();
			main.html('<h1 class="jda_page_title">编辑文章</h1>');
			U._form.create({
				'parent': document.getElementById('jda_main'),
				'id': 'post_edit_form',
				'children': [
					{
						'tag': 'input',
						'type': 'text',
						'value': '',
						'placeholder': '在此输入标题',
						'data_id': 'title',
						'label': '标题'
					},
					{
						'tag': 'input',
						'type': 'text',
						'value': '',
						'placeholder': '作者',
						'data_id': 'author',
						'label': '作者'
					},
					{
						'tag': 'img',
						'src': 'file:///C:/MyGitNotebook/JD-backend/img/logo.png',
						'onclick': function() {
							alert('You clicked me.');
						},
					},
					{
						'tag': 'input',
						'type': 'file',
						'data_id': 'thumbnail',
					},
					{
						'tag': 'editor',
						'class': 'xheditor'
					},
					{
						'tag': 'textarea',
						'data_id': 'excerpt',
						'label': '摘要'
					}
				],
			});
		};
	}, (new TPL()).run());
}