U._trigger('postlist', 'post_list');

M['post_list'] = function(){
	(U._href.getSPAHash('m') == 'post.list') && (TPL = function(){
		this.run = function() {
			var main = $('#jda_main');
			main.empty();
			main.html('<h1 class="jda_page_title">文章列表</h1>');
			main.append('<p class="jda_page_des">这是文章列表页。</p>');
			main.append('<div class="table_utils"><span>全部(2)</span> | <span>已发布(2)</span> | <span>草稿(0)</span> | <span>回收站(0)</span><button class="fr btn-default">批量删除</button></div>');
			U._table.init({
				'id': 'postListTable',
				'chk': true,
				'pagination': true,
				'ths': [
					{'text': '标题', 'type': 'text', 'sortable': true},
					{'text': '作者', 'type': 'text'},
					{'text': '分类目录', 'type': 'text'},
					{'text': '标签', 'type': 'text'},
					{'text': '发布时间', 'type': 'text'},
				],
			});
		};
	}, (new TPL()).run());
}
