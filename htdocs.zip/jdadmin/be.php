<?php 
$method = $_POST['method'];

if( isset($method) && !empty($method) && gettype($method)=='string' ) {
	call_user_func($method);
}

// 课程api
// 获取专辑列表
function getZhuanjiList() {
	$course_list = array(
		array(
			array('text'=> '他可能是封建时代最仁慈的一位皇帝', 'link'=> 10086, 'm'=> 'edit'),
			array('text'=> 'Xuhao Sun'),
			array('text'=> '历史'),
			array('text'=> '封建,皇帝'),
			array('text'=> '2018-03-25 23:00:00'),
			array('text'=> '进入专辑', 'link'=> 10086, 'm'=> 'courseList')
		),
		array(
			array('text'=> '为什么很多人今生不努力，却将希望寄托在来生？', 'link'=> 10010, 'm'=> 'edit'),
			array('text'=> 'Xuhao Sun'),
			array('text'=> '探索'),
			array('text'=> '人生,希望'),
			array('text'=> '2018-03-23 22:30:22'),
			array('text'=> '进入专辑', 'link'=> 10086, 'm'=> 'courseList')
		),
		array(
			array('text'=> '不说爱你，就等于不爱你？', 'link'=> 10000, 'm'=> 'edit'),
			array('text'=> 'Xuhao Sun'),
			array('text'=> '感情'),
			array('text'=> '爱情'),
			array('text'=> '2018-03-22 12:08:28'),
			array('text'=> '进入专辑', 'link'=> 10086, 'm'=> 'courseList')
		),
	);
	echo json_encode($course_list);
	die();
}
// 获取课程列表
function getCourseList() {
	$course_list = array(
		array(
			array('text'=> '第一章', 'link'=> 10086, 'm'=> 'editCourse'),
			array('text'=> 'Xuhao Sun'),
			array('text'=> '2018-03-25 23:00:00')
		),
		array(
			array('text'=> '第二章', 'link'=> 10010, 'm'=> 'editCourse'),
			array('text'=> 'Xuhao Sun'),
			array('text'=> '2018-03-23 22:30:22')
		)
	);
	echo json_encode($course_list);
	die();
}
// 获取专辑详细
function getZhuanjiDetail() {
	$zhuanji_detail = array(
		'title' => '春天在哪里',
		'author' => 'Lee',
		'author_title' => '经济学家',
		'time' => '2018-04-01',
		'excerpt' => '小朋友们，你们知道春天在哪里吗？',
		'cate' => 'zi',
		'label' => '中华,料理',
		'content' => '<h2>歌词：</h2><p>春天在哪里呀，春天在哪里？</p><p>春天在那小朋友的眼睛里。</p><p>这里有红花呀，这里有绿草，还有那会唱歌的小黄鹂。<img alt="大笑" src="js/xheditor/xheditor_emot/default/laugh.gif" /></p><p><img src="666.png" width="100%" alt="" /><br /></p>'
	);
	echo json_encode($zhuanji_detail);
	die();
}
// 获取课程详细
function getCourseDetail() {
	$course_detail = array(
		'title' => '春天里',
		'author' => 'Lee',
		'author_title' => '经济学家',
		'time' => '2018-04-01',
		'excerpt' => '小朋友们，我知道春天在哪里吗？',
		'cate' => 'zi',
		'label' => '中华,料理',
		'content' => '<h2>歌词：</h2><p>春天在哪里呀，春天在哪里？</p><p>春天在那小朋友的眼睛里。</p><p>这里有红花呀，这里有绿草，还有那会唱歌的小黄鹂。<img alt="大笑" src="js/xheditor/xheditor_emot/default/laugh.gif" /></p>'
	);
	echo json_encode($course_detail);
	die();
}

// 媒体库api
function getMediaList() {
	$media_list = array(
		'upload/屏保.png',
		'upload/等等.png',
		'upload/屏保.png',
		'upload/等等.png',
		'upload/屏保.png',
		'upload/等等.png',
		'upload/a.jpg',
		'upload/b.jpg',
		'upload/屏保.png',
		'upload/等等.png'
	);
	echo json_encode($media_list);
	die();
}