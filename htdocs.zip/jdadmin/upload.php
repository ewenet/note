<?php
$res = array(
	'err'=> '',
	'msg'=> '666.png'
);
echo json_encode($res);
die();