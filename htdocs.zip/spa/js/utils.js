var Lee = {};
Lee.Table = function(){
	var data = {};
};

Lee.Table.data = {};

Lee.Table.prototype.init = function(opt) {
	var defaults = {},
		opt = $.extend({}, defaults, opt),
		table = $('<table>'),
		thead = $('<thead>'),
		tbody = $('<tbody>');
		th = '',
		tr = '';
	this.opt = opt;
	if(!opt.el) { return;}
	if(!opt.header) { return;}
	for(var i=0, header=opt.header, len=header.length ;i<len; i++) {
		if(header[i].type=='chk') {
			// this.data['hasChk'] = true;
		}
		var slug = header[i].slug ? ' data-slug="'+header[i].slug+'"' : '';
		var width = header[i].width ? ' width="'+header[i].width+'"' : '';
		th += '<th'+slug+width+'>' + ((header[i].type=='chk') ? 
			'<input type="checkbox">' : 
			'<span>'+header[i].text+'</span>'
			) + '</th>';
	}
	thead.html(th);
	opt.el.append(table);
	table.append(thead);
	table.append(tbody);
	this.render(table, opt.data);
};


Lee.Table.prototype.render = function(table, data) {
	var tr = $('<tr>');
	for(var i=0; i<data.length; i++) {
		var rowData = data[i];
		this.insert(table, rowData);
	}
};

Lee.Table.prototype.insert = function(table, rowData) {
	var tr = $('<tr>');
	var ths = $(table).find('thead th');
	var i = 0;
	for(me in rowData) {
		var slug = $(ths[i]).data('slug');
		var td = $('<td>');
		if(slug == undefined) {
			var html = '<input type="checkbox">';
			td.html(html);
			// i--;
		} else {
			var html = '<span>'+rowData[me]['text']+'</span>';
			td.html(html);
		}
		tr.append(td);
		i++;
	}
	$(table).find('tbody').append(tr);
}