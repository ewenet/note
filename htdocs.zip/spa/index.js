// (function(){
// $(document).ready(function(){

	

	(function() {
		var main;
		$.ajax({
			url: 'app.json',
			type: 'POST',
			success: function(response) {
				main = new Main();
				main.ROUTER = response.router;
				main.Router();

				main.getTpl('header', function(response){
					$('#header').html(response);
				});
			}
		});
	})();

	function Main() {
		// 路由容器
		this.ROUTER = {"index": "index"};
		// 数据巴士
		this.BUS = {};
		// 模块容器
		Main.prototype.M = {};
	};

	//加载tpl
	Main.prototype.getTpl = function(name, fn) {
		if(!name || !fn) { return;}
		$.ajax({
			url: 'tpl/'+name+'.tpl',
			type: 'POST',
			success: function(response){
				fn(response);
			}
		});
	};

	// 路由
	Main.prototype.Router = function() {
		var tis = this;
		(function trigger() {
			function _() {
				var hash = window.location.hash.split('?')[0].slice(1);
				if(hash in tis.ROUTER) {
					tis.getTpl(tis.ROUTER[hash], function(response){
						$('#main').html(response);
					});
				} else {
				}
			}
			$(window).on('popstate.trigger', function(){
				_();
			});
			$(window).on('unload.trigger', function(){
				_();
			});
			_();
		})();
	};


// });
// })();