<?php 
$method = $_POST['method'];

if( isset($method) && !empty($method) && gettype($method)=='string' ) {
	call_user_func($method);
}

// 获取专辑列表
function getAlbumList(){
	$res = array(
		'msg'=> 'ok',
		'data'=> array(
			array(
				'title'=> '儿童经络',
				'author'=> '杜冰',
				'time'=> '2016-12-12 15:33:07',
				'cate'=> '中医',
				'tag'=> '儿童,经络,中医'
			),
			array(
				'title'=> '澎湃讲论语',
				'author'=> '澎湃',
				'time'=> '2017-8-1 10:07:33',
				'cate'=> '经典',
				'tag'=> '事业,论语,澎湃'
			)
		)
	);
	echo json_encode($res);
	die();
}